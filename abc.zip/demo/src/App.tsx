import Approutes from "./Routes/Approutes";


function App() {
  return (
    <>
      {/* <MainPage /> */}
      <Approutes />
    </>
  );
}

export default App;
